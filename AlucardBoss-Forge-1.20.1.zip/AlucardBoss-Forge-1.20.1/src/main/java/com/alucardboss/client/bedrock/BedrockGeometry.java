package com.alucardboss.client.bedrock;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal reader for Bedrock "geometry.*" (format 1.12+) models with per-face UVs.
 * Coordinates are kept in Bedrock model space (pixels, Y up); the model class converts to world space when rendering.
 */
public class BedrockGeometry {

    /** One textured quad of a cube. corners are TL, TR, BR, BL as seen from outside the face. */
    public static final class Face {
        public final float[][] corners = new float[4][];
        public final float[][] uvs = new float[4][];
        public final float[] normal;

        Face(float[] normal) {
            this.normal = normal;
        }
    }

    public static final class Cube {
        public final List<Face> faces = new ArrayList<>();
        public boolean rotated;
        public float[] pivot = new float[3];
        public float[] rotation = new float[3];
    }

    public static final class Bone {
        public final String name;
        public String parentName;
        public Bone parent;
        public float[] pivot = new float[3];
        public float[] rotation = new float[3];
        public final List<Cube> cubes = new ArrayList<>();
        public final List<Bone> children = new ArrayList<>();

        Bone(String name) {
            this.name = name;
        }
    }

    public final List<Bone> roots = new ArrayList<>();
    public final Map<String, Bone> bones = new LinkedHashMap<>();

    public static BedrockGeometry load(ResourceManager manager, ResourceLocation location) throws IOException {
        try (Reader reader = manager.openAsReader(location)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            JsonObject geo = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
            JsonObject desc = geo.getAsJsonObject("description");
            float texW = desc.get("texture_width").getAsFloat();
            float texH = desc.get("texture_height").getAsFloat();

            BedrockGeometry g = new BedrockGeometry();
            for (JsonElement be : geo.getAsJsonArray("bones")) {
                JsonObject bo = be.getAsJsonObject();
                Bone bone = new Bone(bo.get("name").getAsString());
                if (bo.has("parent")) {
                    bone.parentName = bo.get("parent").getAsString();
                }
                if (bo.has("pivot")) {
                    bone.pivot = vec3(bo.getAsJsonArray("pivot"));
                }
                if (bo.has("rotation")) {
                    bone.rotation = vec3(bo.getAsJsonArray("rotation"));
                }
                if (bo.has("cubes")) {
                    for (JsonElement ce : bo.getAsJsonArray("cubes")) {
                        bone.cubes.add(readCube(ce.getAsJsonObject(), texW, texH));
                    }
                }
                g.bones.put(bone.name, bone);
            }
            for (Bone b : g.bones.values()) {
                if (b.parentName != null && g.bones.containsKey(b.parentName)) {
                    b.parent = g.bones.get(b.parentName);
                    b.parent.children.add(b);
                } else {
                    g.roots.add(b);
                }
            }
            return g;
        }
    }

    private static float[] vec3(JsonArray a) {
        return new float[]{a.get(0).getAsFloat(), a.get(1).getAsFloat(), a.get(2).getAsFloat()};
    }

    private static Cube readCube(JsonObject co, float texW, float texH) {
        Cube cube = new Cube();
        float[] o = vec3(co.getAsJsonArray("origin"));
        float[] s = vec3(co.getAsJsonArray("size"));
        float inf = co.has("inflate") ? co.get("inflate").getAsFloat() : 0.0F;
        if (co.has("rotation")) {
            cube.rotated = true;
            cube.rotation = vec3(co.getAsJsonArray("rotation"));
            cube.pivot = co.has("pivot") ? vec3(co.getAsJsonArray("pivot")) : new float[3];
        }

        float x0 = o[0] - inf, y0 = o[1] - inf, z0 = o[2] - inf;
        float x1 = o[0] + s[0] + inf, y1 = o[1] + s[1] + inf, z1 = o[2] + s[2] + inf;

        // Per-face UV: [u, v] is the top-left of the face as seen from outside; uv_size may be negative (flip).
        JsonElement uvEl = co.get("uv");
        float[][] uv = new float[6][]; // north, south, east, west, up, down -> {u, v, w, h}
        if (uvEl.isJsonObject()) {
            JsonObject u = uvEl.getAsJsonObject();
            String[] names = {"north", "south", "east", "west", "up", "down"};
            for (int i = 0; i < 6; i++) {
                if (u.has(names[i])) {
                    JsonObject f = u.getAsJsonObject(names[i]);
                    JsonArray p = f.getAsJsonArray("uv");
                    JsonArray sz = f.getAsJsonArray("uv_size");
                    uv[i] = new float[]{p.get(0).getAsFloat(), p.get(1).getAsFloat(),
                            sz.get(0).getAsFloat(), sz.get(1).getAsFloat()};
                }
            }
        } else { // classic box UV
            JsonArray a = uvEl.getAsJsonArray();
            float u = a.get(0).getAsFloat(), v = a.get(1).getAsFloat();
            float w = s[0], h = s[1], d = s[2];
            uv[0] = new float[]{u + d, v + d, w, h};
            uv[1] = new float[]{u + d + w + d, v + d, w, h};
            uv[2] = new float[]{u, v + d, d, h};
            uv[3] = new float[]{u + d + w, v + d, d, h};
            uv[4] = new float[]{u + d, v, w, d};
            uv[5] = new float[]{u + d + w, v + d, w, -d};
        }

        // corner order: TL, TR, BR, BL (as seen from outside)
        float[][][] pos = {
                // north (-Z): u runs toward -X
                {{x1, y1, z0}, {x0, y1, z0}, {x0, y0, z0}, {x1, y0, z0}},
                // south (+Z): u runs toward +X
                {{x0, y1, z1}, {x1, y1, z1}, {x1, y0, z1}, {x0, y0, z1}},
                // east (+X): u runs toward -Z
                {{x1, y1, z1}, {x1, y1, z0}, {x1, y0, z0}, {x1, y0, z1}},
                // west (-X): u runs toward +Z
                {{x0, y1, z0}, {x0, y1, z1}, {x0, y0, z1}, {x0, y0, z0}},
                // up (+Y): top edge is north, u toward +X
                {{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}},
                // down (-Y): top edge is south, u toward +X
                {{x0, y0, z1}, {x1, y0, z1}, {x1, y0, z0}, {x0, y0, z0}},
        };
        float[][] normals = {{0, 0, -1}, {0, 0, 1}, {1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}};

        for (int i = 0; i < 6; i++) {
            if (uv[i] == null) {
                continue;
            }
            Face f = new Face(normals[i]);
            float u = uv[i][0], v = uv[i][1], w = uv[i][2], h = uv[i][3];
            float[][] uvc = {{u, v}, {u + w, v}, {u + w, v + h}, {u, v + h}};
            for (int c = 0; c < 4; c++) {
                f.corners[c] = pos[i][c];
                f.uvs[c] = new float[]{uvc[c][0] / texW, uvc[c][1] / texH};
            }
            cube.faces.add(f);
        }
        return cube;
    }
}
