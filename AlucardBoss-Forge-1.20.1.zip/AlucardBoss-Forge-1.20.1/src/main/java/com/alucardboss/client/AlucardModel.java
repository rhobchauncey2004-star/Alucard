package com.alucardboss.client;

import com.alucardboss.AlucardBossMod;
import com.alucardboss.client.bedrock.BedrockAnimation;
import com.alucardboss.client.bedrock.BedrockAnimation.Pose;
import com.alucardboss.client.bedrock.BedrockGeometry;
import com.alucardboss.client.bedrock.BedrockGeometry.Bone;
import com.alucardboss.client.bedrock.BedrockGeometry.Cube;
import com.alucardboss.client.bedrock.BedrockGeometry.Face;
import com.alucardboss.entity.AlucardEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Renders the original Bedrock geometry directly (per-face UVs, nested bones) and plays the original
 * keyframe animations. Rotation conventions: Bedrock rotation values equal Java ModelPart values; since this
 * model is built in Bedrock's Y-up space and mirrored into the Java frame, X and Z angles are negated.
 */
public class AlucardModel extends EntityModel<AlucardEntity> {
    private static final String ANIM = "animation.alucard.";

    private final BedrockGeometry geometry;
    private final Map<String, BedrockAnimation> animations;
    private final Map<String, Pose> poses = new HashMap<>();

    public AlucardModel(ResourceManager manager) {
        try {
            this.geometry = BedrockGeometry.load(manager,
                    new ResourceLocation(AlucardBossMod.MOD_ID, "geo/alucard.geo.json"));
            this.animations = BedrockAnimation.load(manager,
                    new ResourceLocation(AlucardBossMod.MOD_ID, "animations/alucard.animation.json"));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load Alucard model data", e);
        }
        for (String name : this.geometry.bones.keySet()) {
            this.poses.put(name, new Pose());
        }
    }

    @Override
    public void setupAnim(AlucardEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        for (Pose p : this.poses.values()) {
            p.reset();
        }
        float partial = ageInTicks - entity.tickCount;

        if (entity.deathTime > 0 || entity.isDeadOrDying()) {
            play("death", (entity.deathTime + partial) / 20.0F);
            return;
        }

        int state = entity.getState();
        float stateTime = Math.max(0.0F, ageInTicks - entity.clientStateStart) / 20.0F;
        String anim = switch (state) {
            case AlucardEntity.STATE_SWING -> "swing";
            case AlucardEntity.STATE_SKILL1 -> "skill1";
            case AlucardEntity.STATE_SKILL2 -> "skill2";
            case AlucardEntity.STATE_SKILL3_READY -> "skill3_ready";
            case AlucardEntity.STATE_SKILL3 -> "skill3";
            case AlucardEntity.STATE_PURSUIT -> "pursuit";
            default -> "general";
        };
        play(anim, stateTime);

        // look_at_target applies to general, swing, skill1 and skill3_ready
        if (state == AlucardEntity.STATE_GENERAL || state == AlucardEntity.STATE_SWING
                || state == AlucardEntity.STATE_SKILL1 || state == AlucardEntity.STATE_SKILL3_READY) {
            Pose head = this.poses.get("Head");
            if (head != null) {
                head.rot[0] += headPitch;
                head.rot[1] += netHeadYaw;
            }
        }

        // walking layer runs after the state animation
        if (limbSwingAmount > 0.05F && state != AlucardEntity.STATE_SKILL2
                && state != AlucardEntity.STATE_SKILL3 && state != AlucardEntity.STATE_SKILL3_READY) {
            play(entity.isAggressive() ? "walk_to_target" : "walk", ageInTicks / 20.0F);
        }
    }

    private void play(String name, float time) {
        BedrockAnimation a = this.animations.get(ANIM + name);
        if (a != null) {
            a.apply(time, this.poses);
        }
    }

    // --------------------------------------------------------------- render

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay,
                               float r, float g, float b, float a) {
        ps.pushPose();
        // Bedrock space (Y up, pixels) -> Java entity frame (Y down, feet at 24px)
        ps.translate(0.0F, 1.5F, 0.0F);
        ps.scale(1.0F, -1.0F, 1.0F);
        for (Bone root : this.geometry.roots) {
            renderBone(root, ps, vc, light, overlay, r, g, b, a);
        }
        ps.popPose();
    }

    private void renderBone(Bone bone, PoseStack ps, VertexConsumer vc, int light, int overlay,
                            float r, float g, float b, float a) {
        Pose p = this.poses.get(bone.name);
        if (Math.abs(p.scl[0]) < 1.0E-3F || Math.abs(p.scl[1]) < 1.0E-3F || Math.abs(p.scl[2]) < 1.0E-3F) {
            return; // hidden effect bones (slashes) are animated in from scale 0
        }
        ps.pushPose();
        ps.translate((bone.pivot[0] + p.pos[0]) / 16.0F, (bone.pivot[1] + p.pos[1]) / 16.0F,
                (bone.pivot[2] + p.pos[2]) / 16.0F);
        rotate(ps, bone.rotation[0] + p.rot[0], bone.rotation[1] + p.rot[1], bone.rotation[2] + p.rot[2]);
        if (p.scl[0] != 1.0F || p.scl[1] != 1.0F || p.scl[2] != 1.0F) {
            ps.scale(p.scl[0], p.scl[1], p.scl[2]);
        }
        ps.translate(-bone.pivot[0] / 16.0F, -bone.pivot[1] / 16.0F, -bone.pivot[2] / 16.0F);

        for (Cube cube : bone.cubes) {
            renderCube(cube, ps, vc, light, overlay, r, g, b, a);
        }
        for (Bone child : bone.children) {
            renderBone(child, ps, vc, light, overlay, r, g, b, a);
        }
        ps.popPose();
    }

    private static void rotate(PoseStack ps, float rxDeg, float ryDeg, float rzDeg) {
        if (rxDeg == 0.0F && ryDeg == 0.0F && rzDeg == 0.0F) {
            return;
        }
        ps.mulPose(new Quaternionf().rotationZYX(
                -rzDeg * ((float) Math.PI / 180.0F),
                ryDeg * ((float) Math.PI / 180.0F),
                -rxDeg * ((float) Math.PI / 180.0F)));
    }

    private void renderCube(Cube cube, PoseStack ps, VertexConsumer vc, int light, int overlay,
                            float r, float g, float b, float a) {
        ps.pushPose();
        if (cube.rotated) {
            ps.translate(cube.pivot[0] / 16.0F, cube.pivot[1] / 16.0F, cube.pivot[2] / 16.0F);
            rotate(ps, cube.rotation[0], cube.rotation[1], cube.rotation[2]);
            ps.translate(-cube.pivot[0] / 16.0F, -cube.pivot[1] / 16.0F, -cube.pivot[2] / 16.0F);
        }
        PoseStack.Pose last = ps.last();
        Matrix4f m = last.pose();
        Matrix3f n = last.normal();
        for (Face f : cube.faces) {
            // emitted twice (both windings) so culling and the mirrored frame never hide a face
            for (int i = 0; i < 4; i++) {
                vertex(vc, m, n, f, i, f.normal[0], f.normal[1], f.normal[2], light, overlay, r, g, b, a);
            }
            for (int i = 3; i >= 0; i--) {
                vertex(vc, m, n, f, i, -f.normal[0], -f.normal[1], -f.normal[2], light, overlay, r, g, b, a);
            }
        }
        ps.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, Face f, int i,
                               float nx, float ny, float nz, int light, int overlay,
                               float r, float g, float b, float a) {
        float[] c = f.corners[i];
        float[] uv = f.uvs[i];
        vc.vertex(m, c[0] / 16.0F, c[1] / 16.0F, c[2] / 16.0F)
                .color(r, g, b, a)
                .uv(uv[0], uv[1])
                .overlayCoords(overlay)
                .uv2(light)
                .normal(n, nx, ny, nz)
                .endVertex();
    }
}
