package com.alucardboss.client;

import com.alucardboss.AlucardBossMod;
import com.alucardboss.entity.AlucardEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;

public class AlucardRenderer extends MobRenderer<AlucardEntity, AlucardModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AlucardBossMod.MOD_ID, "textures/entity/alucard.png");
    private static final ResourceLocation GLOW =
            new ResourceLocation(AlucardBossMod.MOD_ID, "textures/entity/alucard_glow.png");

    public AlucardRenderer(EntityRendererProvider.Context context) {
        super(context, new AlucardModel(context.getResourceManager()), 0.8F);
        this.addLayer(new GlowLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(AlucardEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(AlucardEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.9375F, 0.9375F, 0.9375F);
    }

    /** The corpse plays its own death animation instead of tipping over. */
    @Override
    protected float getFlipDegrees(AlucardEntity entity) {
        return 0.0F;
    }

    /** The original "glow" pass: same geometry, glow texture, ignores lighting. */
    private static class GlowLayer extends RenderLayer<AlucardEntity, AlucardModel> {
        GlowLayer(RenderLayerParent<AlucardEntity, AlucardModel> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AlucardEntity entity,
                           float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                           float netHeadYaw, float headPitch) {
            if (entity.isInvisible()) {
                return;
            }
            VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucentEmissive(GLOW));
            this.getParentModel().renderToBuffer(poseStack, vc, LightTexture.FULL_BRIGHT,
                    LivingEntityRenderer.getOverlayCoords(entity, 0.0F), 1.0F, 1.0F, 1.0F, 1.0F);
        }
    }
}
