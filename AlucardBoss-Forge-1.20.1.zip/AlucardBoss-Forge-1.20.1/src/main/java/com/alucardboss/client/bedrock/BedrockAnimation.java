package com.alucardboss.client.bedrock;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Keyframe animations from a Bedrock *.animation.json file (numeric keyframes only, no Molang). */
public class BedrockAnimation {

    public enum Loop { LOOP, ONCE, HOLD }

    /** One animated property (rotation / position / scale) of one bone. */
    public static final class Channel {
        float[] constant;       // non-null when the channel is a fixed value
        float[] times;
        float[][] pre;
        float[][] post;
        boolean[] smooth;

        /** Writes the value at time t into out[3]. */
        void sample(float t, float[] out) {
            if (constant != null) {
                System.arraycopy(constant, 0, out, 0, 3);
                return;
            }
            int n = times.length;
            if (n == 0) {
                return;
            }
            if (t <= times[0]) {
                System.arraycopy(post[0], 0, out, 0, 3);
                return;
            }
            if (t >= times[n - 1]) {
                System.arraycopy(post[n - 1], 0, out, 0, 3);
                return;
            }
            int i = 0;
            while (i + 1 < n && times[i + 1] <= t) {
                i++;
            }
            float span = times[i + 1] - times[i];
            float f = span <= 1.0E-6F ? 1.0F : (t - times[i]) / span;
            float[] a = post[i];
            float[] b = pre[i + 1];
            if (smooth[i] || smooth[i + 1]) {
                float[] p0 = post[Math.max(i - 1, 0)];
                float[] p3 = pre[Math.min(i + 2, n - 1)];
                for (int k = 0; k < 3; k++) {
                    out[k] = catmullRom(p0[k], a[k], b[k], p3[k], f);
                }
            } else {
                for (int k = 0; k < 3; k++) {
                    out[k] = a[k] + (b[k] - a[k]) * f;
                }
            }
        }

        private static float catmullRom(float p0, float p1, float p2, float p3, float t) {
            return 0.5F * ((2.0F * p1) + (-p0 + p2) * t
                    + (2.0F * p0 - 5.0F * p1 + 4.0F * p2 - p3) * t * t
                    + (-p0 + 3.0F * p1 - 3.0F * p2 + p3) * t * t * t);
        }
    }

    public static final class BoneAnim {
        Channel rotation;
        Channel position;
        Channel scale;
    }

    public float length;
    public Loop loop = Loop.LOOP;
    public boolean override;
    public final Map<String, BoneAnim> bones = new HashMap<>();

    /** Mutable per-bone pose accumulated from one or more animations. */
    public static final class Pose {
        public final float[] rot = new float[3];
        public final float[] pos = new float[3];
        public final float[] scl = {1, 1, 1};

        public void reset() {
            Arrays.fill(rot, 0);
            Arrays.fill(pos, 0);
            Arrays.fill(scl, 1);
        }
    }

    /** Applies this animation at the given time on top of the poses already in the map. */
    public void apply(float time, Map<String, Pose> poses) {
        float t = time;
        if (length > 0) {
            switch (loop) {
                case LOOP -> t = t % length;
                case HOLD -> t = Math.min(t, length);
                case ONCE -> {
                    if (t > length) {
                        return;
                    }
                }
            }
        }
        if (override) {
            for (Pose p : poses.values()) {
                p.reset();
            }
        }
        float[] tmp = new float[3];
        for (Map.Entry<String, BoneAnim> e : bones.entrySet()) {
            Pose p = poses.get(e.getKey());
            if (p == null) {
                continue;
            }
            BoneAnim ba = e.getValue();
            if (ba.rotation != null) {
                Arrays.fill(tmp, 0);
                ba.rotation.sample(t, tmp);
                for (int k = 0; k < 3; k++) {
                    p.rot[k] += tmp[k];
                }
            }
            if (ba.position != null) {
                Arrays.fill(tmp, 0);
                ba.position.sample(t, tmp);
                for (int k = 0; k < 3; k++) {
                    p.pos[k] += tmp[k];
                }
            }
            if (ba.scale != null) {
                Arrays.fill(tmp, 1);
                ba.scale.sample(t, tmp);
                for (int k = 0; k < 3; k++) {
                    p.scl[k] *= tmp[k];
                }
            }
        }
    }

    // ---------------------------------------------------------------- loading

    public static Map<String, BedrockAnimation> load(ResourceManager manager, ResourceLocation location) throws IOException {
        Map<String, BedrockAnimation> result = new HashMap<>();
        try (Reader reader = manager.openAsReader(location)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            JsonObject anims = root.getAsJsonObject("animations");
            for (Map.Entry<String, JsonElement> e : anims.entrySet()) {
                JsonObject ao = e.getValue().getAsJsonObject();
                BedrockAnimation a = new BedrockAnimation();
                a.length = ao.has("animation_length") ? ao.get("animation_length").getAsFloat() : 0.0F;
                if (ao.has("loop")) {
                    JsonElement l = ao.get("loop");
                    if (l.getAsJsonPrimitive().isBoolean()) {
                        a.loop = l.getAsBoolean() ? Loop.LOOP : Loop.ONCE;
                    } else {
                        a.loop = Loop.HOLD; // "hold_on_last_frame"
                    }
                } else {
                    a.loop = Loop.ONCE;
                }
                a.override = ao.has("override_previous_animation") && ao.get("override_previous_animation").getAsBoolean();
                if (ao.has("bones")) {
                    for (Map.Entry<String, JsonElement> be : ao.getAsJsonObject("bones").entrySet()) {
                        JsonObject bo = be.getValue().getAsJsonObject();
                        BoneAnim ba = new BoneAnim();
                        ba.rotation = readChannel(bo.get("rotation"));
                        ba.position = readChannel(bo.get("position"));
                        ba.scale = readChannel(bo.get("scale"));
                        a.bones.put(be.getKey(), ba);
                    }
                }
                result.put(e.getKey(), a);
            }
        }
        return result;
    }

    private static Channel readChannel(JsonElement el) {
        if (el == null || el.isJsonNull()) {
            return null;
        }
        Channel c = new Channel();
        if (el.isJsonPrimitive()) {
            float v = el.getAsFloat();
            c.constant = new float[]{v, v, v};
            return c;
        }
        if (el.isJsonArray()) {
            c.constant = vec(el);
            return c;
        }
        JsonObject o = el.getAsJsonObject();
        List<float[]> keys = new ArrayList<>(); // {time, index}
        List<JsonElement> values = new ArrayList<>();
        for (Map.Entry<String, JsonElement> e : o.entrySet()) {
            keys.add(new float[]{Float.parseFloat(e.getKey()), values.size()});
            values.add(e.getValue());
        }
        keys.sort((x, y) -> Float.compare(x[0], y[0]));
        int n = keys.size();
        c.times = new float[n];
        c.pre = new float[n][];
        c.post = new float[n][];
        c.smooth = new boolean[n];
        for (int i = 0; i < n; i++) {
            c.times[i] = keys.get(i)[0];
            JsonElement v = values.get((int) keys.get(i)[1]);
            if (v.isJsonObject()) {
                JsonObject vo = v.getAsJsonObject();
                float[] post = vo.has("post") ? vec(vo.get("post")) : null;
                float[] pre = vo.has("pre") ? vec(vo.get("pre")) : null;
                if (post == null) {
                    post = pre;
                }
                if (pre == null) {
                    pre = post;
                }
                c.pre[i] = pre;
                c.post[i] = post;
                c.smooth[i] = vo.has("lerp_mode") && "catmullrom".equals(vo.get("lerp_mode").getAsString());
            } else {
                float[] vv = vec(v);
                c.pre[i] = vv;
                c.post[i] = vv;
            }
        }
        return c;
    }

    private static float[] vec(JsonElement el) {
        if (el.isJsonPrimitive()) {
            float v = el.getAsFloat();
            return new float[]{v, v, v};
        }
        JsonArray a = el.getAsJsonArray();
        return new float[]{a.get(0).getAsFloat(), a.get(1).getAsFloat(), a.get(2).getAsFloat()};
    }
}
