package com.alucardboss.entity;

import com.alucardboss.config.AlucardConfig;
import com.alucardboss.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Alucard, the Demon Hunter. Port of the Bedrock "hsph:alucard" boss.
 *
 * Behaviour is a fixed skill rotation that starts when a target is acquired:
 * opening -> [skill1 -> pursuit -> attack -> skill2 -> pursuit -> attack -> skill3 ready -> skill3 -> pursuit
 * -> (consume chain)] -> loops. The synced STATE value drives the client animation:
 * 0 general, 1 swing, 2 skill1, 3 skill2, 4 skill3 ready, 5 skill3, 6 pursuit.
 */
public class AlucardEntity extends Monster {
    public static final int STATE_GENERAL = 0;
    public static final int STATE_SWING = 1;
    public static final int STATE_SKILL1 = 2;
    public static final int STATE_SKILL2 = 3;
    public static final int STATE_SKILL3_READY = 4;
    public static final int STATE_SKILL3 = 5;
    public static final int STATE_PURSUIT = 6;

    /** Death animation / corpse time (the original death entity lived 7.5 seconds). */
    public static final int DEATH_TICKS = 150;

    private static final double VANILLA_MAX_HEALTH = 1024.0;

    private static final EntityDataAccessor<Integer> STATE =
            SynchedEntityData.defineId(AlucardEntity.class, EntityDataSerializers.INT);

    private record Phase(int state, int ticks, double speed, boolean teleport, boolean consume) {}

    private static final Phase OPENING = new Phase(STATE_GENERAL, 40, 0.35, false, false);

    /** Looping rotation, timings converted from the original timers (seconds * 20). */
    private static final Phase[] LOOP = {
            new Phase(STATE_SKILL1, 14, 0.6, true, false),
            new Phase(STATE_PURSUIT, 6, 0.6, true, false),
            new Phase(STATE_SWING, 33, 0.35, false, false),
            new Phase(STATE_SKILL2, 8, 0.0, false, false),
            new Phase(STATE_PURSUIT, 6, 0.6, true, false),
            new Phase(STATE_SWING, 33, 0.35, false, false),
            new Phase(STATE_SKILL3_READY, 17, 0.0, false, false),
            new Phase(STATE_SKILL3, 20, 0.0, false, false),
            new Phase(STATE_PURSUIT, 6, 0.6, true, false),
            // after the ultimate, everything nearby is dragged toward Alucard
            new Phase(STATE_SKILL1, 14, 0.6, true, true),
            new Phase(STATE_SKILL2, 8, 0.0, false, true),
            new Phase(STATE_PURSUIT, 6, 0.6, true, true),
            new Phase(STATE_SKILL2, 8, 0.0, false, true),
            new Phase(STATE_PURSUIT, 6, 0.6, true, true),
            new Phase(STATE_SKILL1, 14, 0.6, true, true),
            new Phase(STATE_SKILL2, 8, 0.0, false, true),
    };

    private static final int CALM_AFTER_TICKS = 600; // original "angry" duration: 30s

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.literal("Alucard Demon Hunter").withStyle(ChatFormatting.BOLD, ChatFormatting.DARK_BLUE),
            BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.PROGRESS);

    private boolean engaged;
    private int loopIndex = -1; // -1 = opening
    private Phase phase = OPENING;
    private int phaseTick;
    private int noTargetTicks;

    /** Client side: tickCount at which the current STATE began (used by the animation system). */
    public int clientStateStart;

    public AlucardEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 10;
        this.setPersistenceRequired();
        this.bossEvent.setDarkenScreen(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, VANILLA_MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.35)
                .add(Attributes.FOLLOW_RANGE, 250.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.ATTACK_DAMAGE, 0.0);
    }

    /** Vanilla caps max health at 1024, so the original HP pool is emulated by scaling damage and healing. */
    private static double hpScale() {
        return VANILLA_MAX_HEALTH / AlucardConfig.tier().health;
    }

    // ------------------------------------------------------------------ setup

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(8, new WaterAvoidingRandomStrollGoal(this, 0.6));
        this.goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 3.0F, 1.0F));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 20,
                false, false, this::isValidHuntTarget));
    }

    private boolean isValidHuntTarget(LivingEntity e) {
        if (e instanceof AlucardEntity || e instanceof ArmorStand || !e.isAlive()) {
            return false;
        }
        if (e instanceof Player p) {
            return AlucardConfig.ATTACK_PLAYERS.get() && !p.isCreative() && !p.isSpectator();
        }
        return e instanceof Enemy;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATE, STATE_GENERAL);
    }

    public int getState() {
        return this.entityData.get(STATE);
    }

    private void setState(int state) {
        this.entityData.set(STATE, state);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (STATE.equals(key)) {
            this.clientStateStart = this.tickCount;
        }
    }

    // ------------------------------------------------------------- boss bar

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    // ------------------------------------------------------------------ tick

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());

        LivingEntity target = this.getTarget();
        boolean hasTarget = target != null && target.isAlive();

        if (hasTarget) {
            this.noTargetTicks = 0;
            if (!this.engaged) {
                this.engage();
            }
        } else if (this.engaged && ++this.noTargetTicks > CALM_AFTER_TICKS) {
            this.calm();
        }

        if (this.engaged) {
            this.tickPhase(hasTarget ? target : null);
        }
    }

    private void engage() {
        this.engaged = true;
        this.setAggressive(true);
        this.loopIndex = -1;
        this.startPhase(OPENING, this.getTarget());
    }

    private void calm() {
        this.engaged = false;
        this.setAggressive(false);
        this.loopIndex = -1;
        this.phase = OPENING;
        this.setState(STATE_GENERAL);
        this.applySpeed(0.35);
    }

    private void startPhase(Phase p, LivingEntity target) {
        this.phase = p;
        this.phaseTick = 0;
        this.setState(p.state);
        this.applySpeed(p.speed);

        if (p.state == STATE_SKILL1 || p.state == STATE_PURSUIT || p.state == STATE_SKILL3
                || p.state == STATE_SKILL3_READY) {
            this.removeAllEffects(); // "/effect @s clear"
        }
        if (target != null) {
            if (p.teleport) {
                this.teleportNear(target);
            }
            this.faceTarget(target);
        }
        switch (p.state) {
            case STATE_SKILL1 -> this.say(ModSounds.SKILL1.get());
            case STATE_SKILL2 -> this.say(ModSounds.SKILL2.get());
            case STATE_SKILL3 -> this.say(ModSounds.SKILL3.get());
            case STATE_SKILL3_READY -> this.say(ModSounds.SKILL3_READY.get());
            case STATE_PURSUIT -> this.say(ModSounds.ATTACK.get());
            default -> { }
        }
    }

    private void tickPhase(LivingEntity target) {
        // movement
        if (target != null) {
            if (this.phase.speed > 0.0) {
                if (this.distanceToSqr(target) > 4.0) {
                    this.getNavigation().moveTo(target, 1.0);
                } else {
                    this.getNavigation().stop();
                }
            } else {
                this.getNavigation().stop();
            }
            int s = this.phase.state;
            if (s == STATE_GENERAL || s == STATE_SWING || s == STATE_SKILL1 || s == STATE_SKILL3_READY) {
                this.getLookControl().setLookAt(target, 60.0F, 60.0F);
            }
            if (s == STATE_SWING || s == STATE_SKILL3_READY) {
                this.faceTarget(target);
            }
        } else {
            this.getNavigation().stop();
        }

        // timeline events (original animation timelines, seconds * 20)
        AlucardConfig.Difficulty t = AlucardConfig.tier();
        switch (this.phase.state) {
            case STATE_SWING -> {
                if (this.phaseTick == 4 || this.phaseTick == 13 || this.phaseTick == 21) {
                    this.say(ModSounds.ATTACK.get());
                    this.aoeHit(8.0, t.attack, true);
                    this.healVirtual(16.0); // instant_health amplifier 2
                }
            }
            case STATE_SKILL1 -> {
                if (this.phaseTick == 13) {
                    this.aoeHit(8.0, t.skill1, false);
                    this.thumpEffect();
                    this.healVirtual(128.0); // amplifier 5
                }
            }
            case STATE_SKILL2 -> {
                if (this.phaseTick % 2 == 0) { // looping 0.1s timeline
                    this.aoeHit(8.0, t.skill2, true);
                }
            }
            case STATE_SKILL3_READY -> {
                if (this.phaseTick == 7) {
                    this.chargeEffect();
                }
            }
            case STATE_SKILL3 -> {
                if (this.phaseTick == 9) {
                    this.aoeHit(15.0, t.skill3, false);
                    if (AlucardConfig.BOSS_HEALING.get()) {
                        this.setHealth(this.getMaxHealth()); // instant_health amplifier 20
                    }
                }
            }
            case STATE_PURSUIT -> {
                if (this.phaseTick == 4) {
                    this.aoeHit(8.0, t.pursuit, true);
                    this.healVirtual(128.0);
                }
            }
            default -> { }
        }

        if (this.phase.consume && this.phaseTick % 2 == 0) {
            this.pullEveryoneIn();
        }

        if (++this.phaseTick >= this.phase.ticks) {
            this.loopIndex = (this.loopIndex + 1) % LOOP.length;
            this.startPhase(LOOP[this.loopIndex], target);
        }
    }

    private void applySpeed(double speed) {
        AttributeInstance inst = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst != null && inst.getBaseValue() != speed) {
            inst.setBaseValue(speed);
        }
    }

    private void faceTarget(LivingEntity target) {
        this.lookAt(EntityAnchorArgument.Anchor.EYES, target.getEyePosition());
        this.setYBodyRot(this.getYRot());
        this.setYHeadRot(this.getYRot());
    }

    private void teleportNear(LivingEntity target) {
        double ang = this.random.nextDouble() * Math.PI * 2.0;
        double dist = 3.0;
        double x = target.getX() + Math.cos(ang) * dist;
        double z = target.getZ() + Math.sin(ang) * dist;
        this.getNavigation().stop();
        this.randomTeleport(x, target.getY(), z, false);
    }

    // ------------------------------------------------------------- skills

    private boolean canHarm(LivingEntity e) {
        if (e == this || e instanceof AlucardEntity || e instanceof ArmorStand || !e.isAlive()) {
            return false;
        }
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    private void aoeHit(double radius, float amount, boolean impactParticles) {
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        AABB box = this.getBoundingBox().inflate(radius);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box, this::canHarm)) {
            if (e.distanceToSqr(this) > radius * radius) {
                continue;
            }
            e.invulnerableTime = 0; // "/damage" ignores hurt cooldown
            e.hurt(this.damageSources().indirectMagic(this, this), amount);
            if (impactParticles) {
                sl.sendParticles(ParticleTypes.SWEEP_ATTACK, e.getX(), e.getY(0.6), e.getZ(), 1, 0, 0, 0, 0);
                sl.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY(0.6), e.getZ(), 12, 0.3, 0.4, 0.3, 0.3);
            }
        }
    }

    private void thumpEffect() {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 0.2, this.getZ(), 6, 3.0, 0.1, 3.0, 0);
            sl.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 0.1, this.getZ(), 60, 3.5, 0.05, 3.5, 0.15);
            sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, this.getX(), this.getY() + 0.1, this.getZ(), 40, 3.0, 0.1, 3.0, 0.1);
        }
    }

    /** Ultimate wind-up: freeze everything within 15 blocks. */
    private void chargeEffect() {
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, this.getX(), this.getY() + 0.5, this.getZ(), 250, 6.0, 0.6, 6.0, 0.05);
        sl.sendParticles(ParticleTypes.ENCHANT, this.getX(), this.getY() + 1.0, this.getZ(), 120, 6.0, 1.0, 6.0, 0.8);
        AABB box = this.getBoundingBox().inflate(15.0);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box, this::canHarm)) {
            if (e.distanceToSqr(this) <= 15.0 * 15.0) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 255, false, false));
                sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, e.getX(), e.getY() + 0.5, e.getZ(), 20, 0.4, 0.6, 0.4, 0.02);
            }
        }
    }

    /** Original "consume": mobs are pulled 3 blocks, players 1 block, toward Alucard every 0.1s. */
    private void pullEveryoneIn() {
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        AABB box = this.getBoundingBox().inflate(150.0);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box, this::canHarm)) {
            double dx = this.getX() - e.getX();
            double dz = this.getZ() - e.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            double stop = 2.0;
            if (dist <= stop) {
                continue;
            }
            double step = Math.min(e instanceof Player ? 1.0 : 3.0, dist - stop);
            double nx = e.getX() + dx / dist * step;
            double nz = e.getZ() + dz / dist * step;
            e.randomTeleport(nx, e.getY(), nz, false);
        }
    }

    private void healVirtual(double virtualHp) {
        if (AlucardConfig.BOSS_HEALING.get()) {
            this.heal((float) (virtualHp * hpScale()));
        }
    }

    private void say(SoundEvent sound) {
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundSource.HOSTILE, 4.0F, 1.0F);
    }

    // ----------------------------------------------------------- damage rules

    private boolean isVulnerableNow() {
        if (!this.engaged) {
            return true; // calm: only fall/explosion immunity applies
        }
        int s = this.phase.state;
        return s == STATE_SKILL1 || s == STATE_SKILL2 || s == STATE_SKILL3_READY;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount); // /kill, void, creative players
        }
        if (source.is(DamageTypeTags.IS_FALL) || source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;
        }
        if (!this.level().isClientSide && this.engaged) {
            if (source.getEntity() instanceof LivingEntity) {
                this.thorn();
            }
            if (!this.isVulnerableNow()) {
                return false;
            }
        }
        return super.hurt(source, amount);
    }

    /** Original "thorn" event: being hit hurts everything within 5 blocks. */
    private void thorn() {
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        float dmg = AlucardConfig.tier().thorn;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(5.0), this::canHarm)) {
            if (e.distanceToSqr(this) <= 25.0) {
                e.invulnerableTime = 0;
                e.hurt(this.damageSources().indirectMagic(this, this), dmg);
            }
        }
    }

    @Override
    protected void actuallyHurt(DamageSource source, float amount) {
        super.actuallyHurt(source, (float) (amount * hpScale()));
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && AlucardConfig.DEATH_BLAST.get() && this.level() instanceof ServerLevel sl) {
            float dmg = AlucardConfig.tier().deathBlast;
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(5.0), this::canHarm)) {
                if (e.distanceToSqr(this) <= 25.0) {
                    e.invulnerableTime = 0;
                    e.hurt(this.damageSources().indirectMagic(this, this), dmg);
                }
            }
        }
        this.bossEvent.setProgress(0.0F);
        super.die(source);
    }

    /** Keep the corpse around for the full death animation instead of vanilla's 20 ticks. */
    @Override
    protected void tickDeath() {
        ++this.deathTime;
        if (this.deathTime >= DEATH_TICKS && !this.level().isClientSide() && !this.isRemoved()) {
            if (this.level() instanceof ServerLevel sl && this.lastHurtByPlayerTime > 0) {
                ExperienceOrb.award(sl, this.position(), this.xpReward);
            }
            this.level().broadcastEntityEvent(this, (byte) 60);
            this.remove(Entity.RemovalReason.KILLED);
        }
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    // ---------------------------------------------------------------- misc

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    /** Slash effect planes are much larger than the hitbox. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(14.0, 6.0, 14.0);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.QUOTE.get();
    }

    @Override
    public int getAmbientSoundInterval() {
        return 600;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.DEATH.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return null;
    }

    @Override
    protected float getSoundVolume() {
        return 4.0F;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.ARMOR_EQUIP_LEATHER, 0.5F, 1.0F);
    }
}
