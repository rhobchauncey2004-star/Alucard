package com.alucardboss.config;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * The original addon shipped two difficulty tiers as Bedrock "subpacks": mid and nightmare.
 * Both are available here through a single setting.
 */
public class AlucardConfig {
    public enum Difficulty {
        /** Original "mid" subpack: 38,627 HP, light damage. */
        MID(38627.0, 8, 15, 8, 100, 10, 8, 500),
        /** Original "nightmare" subpack: 9,883,427 HP, near-lethal damage. */
        NIGHTMARE(9883427.0, 500, 1000, 850, 89999, 950, 25, 1000);

        public final double health;
        public final float attack, skill1, skill2, skill3, pursuit, thorn, deathBlast;

        Difficulty(double health, float attack, float skill1, float skill2, float skill3,
                   float pursuit, float thorn, float deathBlast) {
            this.health = health;
            this.attack = attack;
            this.skill1 = skill1;
            this.skill2 = skill2;
            this.skill3 = skill3;
            this.pursuit = pursuit;
            this.thorn = thorn;
            this.deathBlast = deathBlast;
        }
    }

    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.EnumValue<Difficulty> DIFFICULTY;
    public static final ForgeConfigSpec.BooleanValue ATTACK_PLAYERS;
    public static final ForgeConfigSpec.BooleanValue BOSS_HEALING;
    public static final ForgeConfigSpec.BooleanValue DEATH_BLAST;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("alucard");
        DIFFICULTY = b.comment("MID = original mid pack, NIGHTMARE = original nightmare pack (health and damage tables).")
                .defineEnum("difficulty", Difficulty.MID);
        ATTACK_PLAYERS = b.comment("The original only hunted hostile mobs and retaliated against players who hit it.",
                        "Set true to make Alucard hunt players on sight.")
                .define("attackPlayers", false);
        BOSS_HEALING = b.comment("Original skills heal Alucard (Ultimate fully heals him). Set false to disable.")
                .define("bossHealing", true);
        DEATH_BLAST = b.comment("Original: on death, everything within 5 blocks takes huge damage.")
                .define("deathBlast", true);
        b.pop();
        SPEC = b.build();
    }

    public static Difficulty tier() {
        return DIFFICULTY.get();
    }
}
