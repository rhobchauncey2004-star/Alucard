package com.alucardboss.registry;

import com.alucardboss.AlucardBossMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, AlucardBossMod.MOD_ID);

    public static final RegistryObject<SoundEvent> QUOTE = reg("alucard.quote");
    public static final RegistryObject<SoundEvent> DEATH = reg("alucard.death");
    public static final RegistryObject<SoundEvent> ATTACK = reg("alucard.attack");
    public static final RegistryObject<SoundEvent> SKILL1 = reg("alucard.skill1");
    public static final RegistryObject<SoundEvent> SKILL2 = reg("alucard.skill2");
    public static final RegistryObject<SoundEvent> SKILL3 = reg("alucard.skill3");
    public static final RegistryObject<SoundEvent> SKILL3_READY = reg("alucard.skill3_ready");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () ->
                SoundEvent.createVariableRangeEvent(new ResourceLocation(AlucardBossMod.MOD_ID, name)));
    }
}
