package com.alucardboss.registry;

import com.alucardboss.AlucardBossMod;
import com.alucardboss.entity.AlucardEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, AlucardBossMod.MOD_ID);

    public static final RegistryObject<EntityType<AlucardEntity>> ALUCARD = ENTITIES.register("alucard",
            () -> EntityType.Builder.of(AlucardEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.9F)
                    .fireImmune()
                    .clientTrackingRange(12)
                    .build(AlucardBossMod.MOD_ID + ":alucard"));
}
