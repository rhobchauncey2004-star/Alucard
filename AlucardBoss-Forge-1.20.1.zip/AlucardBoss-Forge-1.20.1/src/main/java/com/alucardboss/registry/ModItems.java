package com.alucardboss.registry;

import com.alucardboss.AlucardBossMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(Registries.ITEM, AlucardBossMod.MOD_ID);

    public static final RegistryObject<Item> ALUCARD_SPAWN_EGG = ITEMS.register("alucard_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ALUCARD, 0x1B2A7A, 0x4AA8FF, new Item.Properties()));
}
