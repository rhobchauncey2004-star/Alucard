# Alucard Boss – Forge 1.20.1

Standalone Forge port of **Alucard Boss V2** (Bedrock addon by HyperSoulPH). No GeckoLib or other dependencies.

## Build
Requires JDK 17+ and an internet connection for the first build (ForgeGradle downloads Forge 47.3.0).

```
./gradlew build        # jar ends up in build/libs/alucardboss-1.0.0.jar
./gradlew runClient    # test in a dev client
```
Drop the jar in `mods/` of a Forge 1.20.1 (47.x) install.

## Use
Creative inventory → Spawn Eggs → **Alucard Spawn Egg** (or `/summon alucardboss:alucard`).

## What was ported
- Original model (`geometry.alucard`) rendered directly from the Bedrock JSON, with per-face UVs.
- All original keyframe animations: idle, walk, walk-to-target, swing, skill 1, skill 2, skill 3 ready, skill 3, pursuit, death.
- Original textures, glow texture (sword + slash effects render as a full-bright overlay), spawn egg icon.
- All 13 sounds (converted WAV → OGG, mono).
- Behaviour: opening 2s, then the looping skill rotation from the behavior pack
  (skill 1 → pursuit → attack ×3 hits → skill 2 → pursuit → attack → ultimate wind-up (freezes everything within 15) → ultimate → pursuit →
  "consume" chain that drags everyone toward him → repeat). Teleport-dashes to the target on skill 1/pursuit.
- Invulnerable except during skill 1, skill 2 and ultimate wind-up (as in the original). Being hit deals "thorn" damage within 5 blocks.
  Immune to fall and explosion damage, fire and knockback. Boss bar. Hunts hostile mobs; retaliates against players who hit him.
- Both difficulty packs (`mid` / `nightmare`) via config `alucardboss-common.toml`: health and the full damage tables.

## Differences from the Bedrock version
- Vanilla caps max health at 1024, so the 38,627 / 9,883,427 HP pools are emulated by scaling damage and healing. The boss bar and
  `/data` show a 1024 HP bar.
- Original custom particles are replaced with vanilla particles (sweep, crit, soul fire, cloud, enchant).
- The separate "death" entity is folded into Alucard himself: he plays the death animation for 7.5 s, then disappears.
- Original skills heal him (the ultimate heals him fully) and his death blast hits everything within 5 blocks. Both are faithful defaults and can be
  turned off in the config (`bossHealing`, `deathBlast`). `attackPlayers` makes him hunt players on sight.
- Skill damage ignores armor (magic damage attributed to Alucard) and the hurt cooldown, like Bedrock's `/damage ... suicide`.
