package com.alucardbosstab.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** A particle lying flat on the ground (the Bedrock "emitter_transform_xz" billboards). */
public class FlatParticle extends TextureSheetParticle {

    /** Additive blending, no depth write: the glowing blue squares. */
    public static final ParticleRenderType ADDITIVE = new ParticleRenderType() {
        @Override
        public void begin(BufferBuilder builder, TextureManager textures) {
            RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getParticleShader);
            RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_PARTICLES);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            builder.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
        }

        @Override
        public void end(Tesselator tesselator) {
            tesselator.end();
            RenderSystem.defaultBlendFunc();
            RenderSystem.depthMask(true);
        }

        @Override
        public String toString() {
            return "ALUCARD_ADDITIVE";
        }
    };

    private final boolean additive;
    private final float fadeStart;
    private final float drag;
    private final float yaw;

    public FlatParticle(ClientLevel level, double x, double y, double z, double vx, double vz,
                        SpriteSet sprites, float size, int lifetime, boolean additive,
                        float fadeStart, float drag, float yaw) {
        super(level, x, y, z, 0.0, 0.0, 0.0);
        this.xd = vx;
        this.yd = 0.0;
        this.zd = vz;
        this.hasPhysics = false;
        this.gravity = 0.0F;
        this.quadSize = size * 0.5F; // half extent
        this.lifetime = lifetime;
        this.additive = additive;
        this.fadeStart = fadeStart;
        this.drag = drag;
        this.yaw = yaw;
        this.pickSprite(sprites);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        this.x += this.xd;
        this.z += this.zd;
        this.xd *= this.drag;
        this.zd *= this.drag;
        float t = (float) this.age / (float) this.lifetime;
        this.alpha = t < this.fadeStart ? 1.0F : Math.max(0.0F, 1.0F - (t - this.fadeStart) / (1.0F - this.fadeStart));
    }

    @Override
    public ParticleRenderType getRenderType() {
        return this.additive ? ADDITIVE : ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 15728880; // full bright
    }

    @Override
    public void render(VertexConsumer vc, Camera camera, float partialTick) {
        Vec3 cam = camera.getPosition();
        float cx = (float) (Mth.lerp(partialTick, this.xo, this.x) - cam.x());
        float cy = (float) (Mth.lerp(partialTick, this.yo, this.y) - cam.y());
        float cz = (float) (Mth.lerp(partialTick, this.zo, this.z) - cam.z());
        float h = this.quadSize;
        float cos = Mth.cos(this.yaw);
        float sin = Mth.sin(this.yaw);
        float[][] c = {{-h, -h}, {h, -h}, {h, h}, {-h, h}};
        float[][] uv = {{this.getU0(), this.getV1()}, {this.getU1(), this.getV1()},
                {this.getU1(), this.getV0()}, {this.getU0(), this.getV0()}};
        int light = this.getLightColor(partialTick);
        // both windings so the quad is visible from above and below
        for (int pass = 0; pass < 2; pass++) {
            for (int k = 0; k < 4; k++) {
                int i = pass == 0 ? k : 3 - k;
                float lx = c[i][0];
                float lz = c[i][1];
                vc.vertex(cx + lx * cos - lz * sin, cy + 0.03F, cz + lz * cos + lx * sin)
                        .uv(uv[i][0], uv[i][1])
                        .color(this.rCol, this.gCol, this.bCol, this.alpha)
                        .uv2(light)
                        .endVertex();
            }
        }
    }
}
