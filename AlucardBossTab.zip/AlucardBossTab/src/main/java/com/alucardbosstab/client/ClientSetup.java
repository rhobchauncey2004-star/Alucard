package com.alucardbosstab.client;

import com.alucardbosstab.AlucardTabMod;
import com.alucardbosstab.ModParticles;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AlucardTabMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.THUMP.get(), ThumpProvider::new);
        event.registerSpriteSet(ModParticles.CRACK.get(), CrackProvider::new);
        event.registerSpriteSet(ModParticles.HIT_IMPACT.get(), HitProvider::new);
        event.registerSpriteSet(ModParticles.AURA.get(), AuraProvider::new);
    }

    /** xd/zd = horizontal velocity per tick. */
    private record ThumpProvider(SpriteSet sprites) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xd, double yd, double zd) {
            return new FlatParticle(level, x, y, z, xd, zd, this.sprites, 1.1F, 4, true, 0.5F, 0.8F, 0.0F);
        }
    }

    /** xd = yaw (radians). */
    private record CrackProvider(SpriteSet sprites) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xd, double yd, double zd) {
            return new FlatParticle(level, x, y, z, 0.0, 0.0, this.sprites, 5.0F, 20, false, 0.84F, 1.0F, (float) xd);
        }
    }

    private record HitProvider(SpriteSet sprites) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xd, double yd, double zd) {
            return new SpriteBurstParticle(level, x, y, z, 0.0, 0.0, 0.0, this.sprites, 2.5F, 5, 1.0F, 0.0, true);
        }
    }

    /** xd/yd/zd = velocity per tick. Moving inward ("slash ready") when yd == 99 is not used; plain drift. */
    private record AuraProvider(SpriteSet sprites) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xd, double yd, double zd) {
            return new SpriteBurstParticle(level, x, y, z, xd, yd, zd, this.sprites, 0.8F, 20, 0.9F, 0.0, false);
        }
    }
}
