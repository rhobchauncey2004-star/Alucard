package com.alucardbosstab.client;

import com.alucardbosstab.AlucardTabMod;
import com.alucardbosstab.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

/**
 * Plays Alucard's original Bedrock particle effects. Runs purely on the client: it watches Alucard's animation
 * state (the main mod's public getState()) and fires each effect at the same moment the attack lands.
 * States: 1 swing, 2 skill 1 (slam), 3 skill 2 (spin), 4 ultimate wind-up, 5 ultimate, 6 pursuit.
 */
@Mod.EventBusSubscriber(modid = AlucardTabMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class AlucardEffects {
    private static final Random RNG = new Random();
    private static Method getState;
    private static boolean reflectionFailed;

    /** entity id -> {lastState, tick the state began} */
    private static final Map<Integer, long[]> TRACK = new HashMap<>();

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.isPaused() || reflectionFailed) {
            if (level == null) {
                TRACK.clear();
            }
            return;
        }
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation("alucardboss", "alucard"));
        if (type == null) {
            return;
        }
        long now = level.getGameTime();
        Map<Integer, Boolean> seen = new HashMap<>();
        for (Entity e : level.entitiesForRendering()) {
            if (e.getType() != type || !(e instanceof LivingEntity alucard) || alucard.isDeadOrDying()) {
                continue;
            }
            int state = readState(e);
            if (state < 0) {
                return;
            }
            seen.put(e.getId(), true);
            long[] t = TRACK.computeIfAbsent(e.getId(), id -> new long[]{state, now});
            if (t[0] != state) {
                t[0] = state;
                t[1] = now;
            }
            fire(level, alucard, state, (int) (now - t[1]));
        }
        Iterator<Integer> it = TRACK.keySet().iterator();
        while (it.hasNext()) {
            if (!seen.containsKey(it.next())) {
                it.remove();
            }
        }
    }

    private static int readState(Entity e) {
        try {
            if (getState == null) {
                getState = e.getClass().getMethod("getState");
            }
            return (Integer) getState.invoke(e);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            reflectionFailed = true;
            return -1;
        }
    }

    private static void fire(ClientLevel level, LivingEntity a, int state, int elapsed) {
        switch (state) {
            case 1 -> { // swing: three hits
                if (elapsed == 4 || elapsed == 13 || elapsed == 21) {
                    hitImpacts(level, a, 8.0);
                }
            }
            case 2 -> { // skill 1: slam
                if (elapsed == 13) {
                    slam(level, a);
                }
            }
            case 3 -> { // skill 2: spin
                if (elapsed == 1 || elapsed == 3 || elapsed == 5) {
                    hitImpacts(level, a, 8.0);
                }
            }
            case 4 -> { // ultimate wind-up
                if (elapsed == 7) {
                    aura(level, a.getX(), a.getY(), a.getZ());
                    converge(level, a);
                }
                if (elapsed == 8) {
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, a.getBoundingBox().inflate(15.0))) {
                        if (e != a && !(e instanceof ArmorStand) && e.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)
                                && e.distanceToSqr(a) <= 225.0) {
                            aura(level, e.getX(), e.getY(), e.getZ());
                        }
                    }
                }
            }
            case 6 -> {
                if (elapsed == 4) {
                    hitImpacts(level, a, 8.0);
                }
            }
            default -> { }
        }
    }

    /** Impact flash on everything near him that was just hurt. */
    private static void hitImpacts(ClientLevel level, LivingEntity a, double radius) {
        AABB box = a.getBoundingBox().inflate(radius);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (e == a || e instanceof ArmorStand || e.hurtTime <= 0 || e.distanceToSqr(a) > radius * radius) {
                continue;
            }
            for (int i = 0; i < 2; i++) {
                level.addParticle(ModParticles.HIT_IMPACT.get(),
                        e.getX() + (RNG.nextDouble() - 0.5) * 0.4, e.getY() + 1.0, e.getZ() + (RNG.nextDouble() - 0.5) * 0.4,
                        0, 0, 0);
            }
        }
    }

    /** Glowing disc of blue squares racing outward along the ground, plus the blue ground crack. */
    private static void slam(ClientLevel level, LivingEntity a) {
        for (int i = 0; i < 250; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2.0;
            double r0 = Math.sqrt(RNG.nextDouble());
            double vx = Math.cos(ang) * 1.6;
            double vz = Math.sin(ang) * 1.6;
            level.addParticle(ModParticles.THUMP.get(),
                    a.getX() + Math.cos(ang) * r0, a.getY() + 0.1, a.getZ() + Math.sin(ang) * r0, vx, 0.0, vz);
        }
        float yaw = (float) Math.toRadians(-a.yBodyRot);
        level.addParticle(ModParticles.CRACK.get(), a.getX(), a.getY() + 0.1, a.getZ(), yaw, 0.0, 0.0);
    }

    /** 75 aura sprites rising off the ground around a point. */
    private static void aura(ClientLevel level, double x, double y, double z) {
        for (int i = 0; i < 75; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2.0;
            double r = 1.0;
            level.addParticle(ModParticles.AURA.get(), x + Math.cos(ang) * r, y + 1.0, z + Math.sin(ang) * r,
                    0.0, 0.25, 0.0);
        }
    }

    /** 40 aura sprites flying in from a 20-block sphere toward him. */
    private static void converge(ClientLevel level, LivingEntity a) {
        for (int i = 0; i < 40; i++) {
            double ux = RNG.nextGaussian();
            double uy = RNG.nextGaussian();
            double uz = RNG.nextGaussian();
            double len = Math.sqrt(ux * ux + uy * uy + uz * uz);
            if (len < 1.0E-4) {
                continue;
            }
            ux /= len;
            uy /= len;
            uz /= len;
            level.addParticle(ModParticles.AURA.get(),
                    a.getX() + ux * 20.0, a.getY() + 3.0 + uy * 20.0, a.getZ() + uz * 20.0,
                    -ux * 2.2, -uy * 2.2, -uz * 2.2);
        }
    }
}
