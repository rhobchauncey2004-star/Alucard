package com.alucardbosstab.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;

/** Camera-facing sprite that drifts, slows down and fades (hit impacts, aura). */
public class SpriteBurstParticle extends TextureSheetParticle {
    private final float drag;
    private final double lift;

    public SpriteBurstParticle(ClientLevel level, double x, double y, double z,
                               double vx, double vy, double vz, SpriteSet sprites,
                               float size, int lifetime, float drag, double lift, boolean spin) {
        super(level, x, y, z, 0.0, 0.0, 0.0);
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.hasPhysics = false;
        this.gravity = 0.0F;
        this.quadSize = size * 0.5F;
        this.lifetime = lifetime;
        this.drag = drag;
        this.lift = lift;
        if (spin) {
            this.roll = this.oRoll = (float) (this.random.nextFloat() * Math.PI * 2.0);
        }
        this.pickSprite(sprites);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        this.yd += this.lift;
        this.x += this.xd;
        this.y += this.yd;
        this.z += this.zd;
        this.xd *= this.drag;
        this.yd *= this.drag;
        this.zd *= this.drag;
        float t = (float) this.age / (float) this.lifetime;
        this.alpha = t < 0.5F ? 1.0F : Math.max(0.0F, 1.0F - (t - 0.5F) * 2.0F);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 15728880;
    }
}
