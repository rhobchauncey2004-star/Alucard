package com.alucardbosstab;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Add-on for the Alucard Boss mod: a separate creative tab for his spawn egg, plus his original
 * Bedrock particle effects (ground crack, slam disc, hit impacts, ultimate aura).
 * Needs the main "alucardboss" mod.
 */
@Mod(AlucardTabMod.MOD_ID)
public class AlucardTabMod {
    public static final String MOD_ID = "alucardbosstab";

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<CreativeModeTab> ALUCARD_TAB = TABS.register("alucard_boss",
            () -> CreativeModeTab.builder()
                    .title(Component.literal("Alucard Boss"))
                    .icon(() -> new ItemStack(egg()))
                    .displayItems((params, output) -> output.accept(egg()))
                    .build());

    private static Item egg() {
        return ForgeRegistries.ITEMS.getValue(new ResourceLocation("alucardboss", "alucard_spawn_egg"));
    }

    public AlucardTabMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        TABS.register(bus);
        ModParticles.PARTICLES.register(bus);
    }
}
