package com.alucardbosstab;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, AlucardTabMod.MOD_ID);

    /** Flat glowing blue squares that fly outward along the ground (skill 1 slam). */
    public static final RegistryObject<SimpleParticleType> THUMP = reg("thump");
    /** Large blue ground crack that fades out. */
    public static final RegistryObject<SimpleParticleType> CRACK = reg("crack");
    /** Star-shaped hit flash. */
    public static final RegistryObject<SimpleParticleType> HIT_IMPACT = reg("hit_impact");
    /** Demon-hunter aura sprites (ultimate wind-up). */
    public static final RegistryObject<SimpleParticleType> AURA = reg("aura");

    private static RegistryObject<SimpleParticleType> reg(String name) {
        return PARTICLES.register(name, () -> new SimpleParticleType(false));
    }
}
